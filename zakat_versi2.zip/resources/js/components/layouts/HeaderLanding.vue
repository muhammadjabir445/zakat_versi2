<template>
	<nav>
		<v-app-bar app color="teal darken-2" class="white--text" >
		    <v-toolbar-title>Website BMT At-Taqwa</v-toolbar-title>
		    <v-spacer></v-spacer>

		    <v-btn class="white--text" text to="/" >Home</v-btn>
		    <v-btn class="white--text" text to="/kalkulator-zakat" >Kalkulator Zakat</v-btn>
		    <v-btn class="white--text" text to="/bayar-zakat" >Bayar Zakat</v-btn>
		    <v-btn class="white--text" text to="/cek-pembayaran" >Cek Pembayaran</v-btn>

		  </v-app-bar>
	</nav>

</template>
<script>

</script>
