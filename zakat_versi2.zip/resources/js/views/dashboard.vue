<template>
    <div>
    <v-container>
        <v-row>
            <v-col
            cols="12"
            md="3"
            >
                <v-card
                class="border-edit"
                tile

                >
                <v-btn small color="teal darken-2" class="white--text" tile>Total Uang</v-btn>
                    <v-card-text class="text-center">
                    <h3>Rp.300.000.000</h3>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>

            <v-col
            cols="12"
            md="3"
            >
                <v-card
                class="border-edit"
                tile

                >
                <v-btn small color="teal darken-2" class="white--text" tile>Total Beras</v-btn>
                    <v-card-text class="text-center">
                    <h3>340Kg</h3>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>

            <v-col
            cols="12"
            md="3"
            >
                <v-card
                class="border-edit"
                tile

                >
                <v-btn small color="teal darken-2" class="white--text" tile>Penyalur Zakat</v-btn>
                    <v-card-text class="text-center">
                    <h3>12 Lembaga</h3>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>

            <v-col
            cols="12"
            md="3"
            >
                <v-card
                class="border-edit"
                tile

                >
                <v-btn small color="teal darken-2" class="white--text" tile>Total Mustahik</v-btn>
                    <v-card-text class="text-center">
                    <h3>600 Orang</h3>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>
        </v-row>

         <v-card
                class="border-edit"
                tile

                >
                <v-btn small color="teal darken-2" class="white--text" tile>BMT At-Taqwa</v-btn>
                    <v-card-text class="text-center">
                    <v-img src="https://attaqwakemanggisan.files.wordpress.com/2013/07/msjid-attaqwa21.jpg" aspect-ratio="1.7"></v-img>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
    </v-container>

    </div>
</template>
