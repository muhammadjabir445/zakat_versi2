<template>
    <v-app>
        <v-row>
            <v-col
            cols="12"
            md="8"
            >
            <v-card
                class="border-edit"
                tile
                >
                <v-btn small color="teal darken-2" class="white--text" tile>BMT At-Taqwa</v-btn>
                    <v-card-text class="text-center">
                    <v-img src="https://attaqwakemanggisan.files.wordpress.com/2013/07/msjid-attaqwa21.jpg" aspect-ratio="1.7"></v-img>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>

            <v-col
            cols="12"
            md="4"
            >
            <v-card
                class="border-edit mb-3"
                tile
                >
                <v-btn small color="teal darken-2" class="white--text" tile>Profil BMT At-Taqwa</v-btn>
                    <v-card-text class="text-center">
                    <p>Baitul Maal Watamwil AT-TAQWA berdiri sejak tahun 1994, lahir sebagai solusi dari pembagian dana zakat,
                         untuk memperdayakan masyarakat khususnya di sekitar masjid At-Taqwa dan sekitarnya. Dalam bentuk ZIS dan wakaf untuk dikelola
                         secara produktif dan disalurkan dalam bentuk pembiayaan Al-Qard, serta dana simpanan dari anggota yang dikelola secara profitable untuk disalurkan kepada
                         usaha mikro kecil dalam bentuk pembiayaan dalam bentuk pembiayaan dengan skema sistem bagi hasil dan jual beli.</p>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>

            <v-card
                class="border-edit mb-3"
                tile
                >
                <v-btn small color="teal darken-2" class="white--text" tile>Visi BMT At-Taqwa</v-btn>
                    <v-card-text class="text-center">
                    <p>“Menjadi lembaga keuangan Islam yang ikut menunjang dan memajukan perekonomian umat, sehingga menjadikan lembaga yang dapat dipercaya masyarakat dan tumbuh sebagai lembaga yang menjawab tantanganperekonomian nasional khususnya ekonomi mikro dalam mengentaskan kemiskinan.”</p>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>

            <v-card
                class="border-edit"
                tile
                >
                <v-btn small color="teal darken-2" class="white--text" tile>Misi BMT At-Taqwa</v-btn>
                    <v-card-text class="text-center">
                    <p>“Menjadikan BMT At-Taqwa sebagai koperasi jasa keuangan syariah yang dapat bersaing dalam hal kesehatan. Profitable efisien dan sebagai pilar ekonomi yaitu sebagai bagian dari syiar islam dalam bidang ekonomi.” </p>
                    </v-card-text>

                    <v-card-actions class="">

                    </v-card-actions>
            </v-card>
            </v-col>
        </v-row>
    </v-app>
</template>

<script>

</script>

<style>

</style>
